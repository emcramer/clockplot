# clockplot
Plotting utility for a "clockplot" that puts groups into a time-ordered heterogeneity visualization
